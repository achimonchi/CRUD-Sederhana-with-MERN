const jwt_key = "challange"

module.exports = jwt_key;